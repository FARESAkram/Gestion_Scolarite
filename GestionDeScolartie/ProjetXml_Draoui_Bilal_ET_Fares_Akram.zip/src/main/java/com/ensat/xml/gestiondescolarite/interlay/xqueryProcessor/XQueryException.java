package com.ensat.xml.gestiondescolarite.interlay.xqueryProcessor;

public class XQueryException extends Exception {

    public XQueryException(String message) {
        super(message);
    }

}
