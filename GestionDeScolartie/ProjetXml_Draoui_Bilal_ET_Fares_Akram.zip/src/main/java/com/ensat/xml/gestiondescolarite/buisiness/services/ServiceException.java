package com.ensat.xml.gestiondescolarite.buisiness.services;

public class ServiceException extends Exception
{
    public ServiceException(String message) {
        super(message);
    }
}