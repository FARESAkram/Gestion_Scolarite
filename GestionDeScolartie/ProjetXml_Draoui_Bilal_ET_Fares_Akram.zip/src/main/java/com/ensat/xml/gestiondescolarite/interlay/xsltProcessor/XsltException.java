package com.ensat.xml.gestiondescolarite.interlay.xsltProcessor;

public class XsltException extends Exception{

    public XsltException(String message) {
        super(message);
    }
}
