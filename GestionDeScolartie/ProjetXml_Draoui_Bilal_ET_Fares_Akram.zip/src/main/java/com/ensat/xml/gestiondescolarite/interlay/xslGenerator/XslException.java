package com.ensat.xml.gestiondescolarite.interlay.xslGenerator;

public class XslException extends Exception
{
    public XslException(String message) {
        super(message);
    }
}